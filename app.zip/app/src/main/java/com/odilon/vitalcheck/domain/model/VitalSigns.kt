package com.odilon.vitalcheck.domain.model

data class VitalSigns(
    val heartRate: Int,
    val steps: Int
)

